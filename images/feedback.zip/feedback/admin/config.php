<?php
date_default_timezone_set("Europe/London");

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "feedback";

$con = mysqli_connect($servername, $username, $password, $databasename);

if (!$con) {
    die("Failed to connect: " . mysqli_connect_error());
}
?>

