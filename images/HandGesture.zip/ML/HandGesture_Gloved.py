import numpy as np
import cv2
import cv2.aruco as aruco
import glob
import math
import pyautogui
import time
import os

class Marker:
    def __init__(self, dict_type = aruco.DICT_4X4_50, thresh_constant = 1):
        self.aruco_dict = aruco.Dictionary(dict_type)
        self.parameters = aruco.DetectorParameters_create()
        self.parameters.adaptiveThreshConstant = thresh_constant
        self.corners = None # corners of Marker
        self.marker_x2y = 1 # width:height ratio
        self.mtx, self.dist = self.calibrate()
    
    def calibrate(self):
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
        objp = np.zeros((6*7,3), np.float32)
        objp[:,:2] = np.mgrid[0:7,0:6].T.reshape(-1,2)
        objpoints = [] # 3d point in real world space
        imgpoints = [] # 2d points in image plane.
        path = os.path.dirname(os.path.abspath(__file__))
        p1 = path + r'\calib_images\checkerboard\*.jpg'
        images = glob.glob(p1)
        for fname in images:
            img = cv2.imread(fname)
            gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
            ret, corners = cv2.findChessboardCorners(gray, (7,6),None)
            if ret == True:
                objpoints.append(objp)
                corners2 = cv2.cornerSubPix(gray,corners,(11,11),(-1,-1),criteria)
                imgpoints.append(corners2)
                img = cv2.drawChessboardCorners(img, (7,6), corners2,ret)
                
        ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(objpoints, imgpoints, gray.shape[::-1],None,None)
        
        #mtx = [[534.34144579,0.0,339.15527836],[0.0,534.68425882,233.84359493],[0.0,0.0,1.0]]
        #dist = [[-2.88320983e-01, 5.41079685e-02, 1.73501622e-03, -2.61333895e-04, 2.04110465e-01]]
        return mtx, dist
    
    def detect(self, frame):
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        self.corners, ids, rejectedImgPoints = aruco.detectMarkers(gray_frame, self.aruco_dict, parameters = self.parameters)
        if np.all(ids != None):
            rvec, tvec ,_ = aruco.estimatePoseSingleMarkers(self.corners, 0.05, self.mtx, self.dist)
        else:
            self.corners = None
    
    def is_detected(self):
        if self.corners:
            return True
        return False
    
    def draw_marker(self, frame):
        aruco.drawDetectedMarkers(frame, self.corners)
    
        

def ecu_dis(p1, p2):
    dist = np.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)
    return dist

def find_HSV(samples):
    try:
        color = np.uint8([ samples ])
    except:
        color = np.uint8([ [[105,105,50]] ])
    hsv_color = cv2.cvtColor(color,cv2.COLOR_RGB2HSV)
    #print( hsv_color )
    return hsv_color

def draw_box(frame, points, color=(0,255,127)):
    if points:
        frame = cv2.line(frame, points[0], points[1], color, thickness=2, lineType=8) #top
        frame = cv2.line(frame, points[1], points[2], color, thickness=2, lineType=8) #right
        frame = cv2.line(frame, points[2], points[3], color, thickness=2, lineType=8) #bottom
        frame = cv2.line(frame, points[3], points[0], color, thickness=2, lineType=8) #left

def in_cam(val, type_):
    if type_ == 'x':
        if val<0:
            return 0
        if val>GestureController.cam_width:
            return GestureController.cam_width
    elif type_ == 'y':
        if val<0:
            return 0
        if val>GestureController.cam_height:
            return GestureController.cam_height
    return val

    
class ROI:
    def __init__(self, roi_alpha1=1.5, roi_alpha2=1.5, roi_beta=2.5, hsv_alpha = 0.3, hsv_beta = 0.5, hsv_lift_up = 0.3):
        self.roi_alpha1 = roi_alpha1
        self.roi_alpha2 = roi_alpha2
        self.roi_beta = roi_beta
        self.roi_corners = None
        
        self.hsv_alpha = hsv_alpha
        self.hsv_beta = hsv_beta
        self.hsv_lift_up = hsv_lift_up
        self.hsv_corners = None
        
        self.marker_top = None
        self.glove_hsv = None
        
    def findROI(self, frame, marker):
        rec_coor = marker.corners[0][0]
        c1 = (int(rec_coor[0][0]),int(rec_coor[0][1]))
        c2 = (int(rec_coor[1][0]),int(rec_coor[1][1]))
        c3 = (int(rec_coor[2][0]),int(rec_coor[2][1]))
        c4 = (int(rec_coor[3][0]),int(rec_coor[3][1]))
        
        try:
            marker.marker_x2y = np.sqrt((c1[0]-c2[0])**2 + (c1[1]-c2[1])**2) / np.sqrt((c3[0]-c2[0])**2 + (c3[1]-c2[1])**2)
        except:
            marker.marker_x2y = 999.0
        
        #mid-point of top line of Marker
        cx = (c1[0] + c2[0])/2
        cy = (c1[1] + c2[1])/2
        
        self.marker_top = [cx, cy]
        
        #distance between top and bottom of Marker
        l1 = ecu_dis(c1,c3)
        l2 = ecu_dis(c2,c4)
        self.roi_beta = (l1+l2)/2
        
        self.roi_alpha1 = 2 * self.roi_beta / 5
        self.roi_alpha2 = 3 * self.roi_beta / 5
        
        return (int(cx),int(cy)), int(self.roi_alpha1), int(self.roi_alpha2), int(self.roi_beta)
    
    def find_glove_hsv(self, frame):
        try:
            # Creating a mask
            lower = (int(self.glove_hsv[0]-self.hsv_alpha*179),int(self.glove_hsv[1]-self.hsv_beta*255),int(self.glove_hsv[2]-self.hsv_lift_up*255))
            upper = (int(self.glove_hsv[0]+self.hsv_alpha*179),int(self.glove_hsv[1]+self.hsv_beta*255),int(self.glove_hsv[2]+self.hsv_lift_up*255))
            hsv_frame = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv_frame, np.array(lower), np.array(upper))
            res = cv2.bitwise_and(frame,frame, mask= mask)
            hsv_glove = cv2.mean(hsv_frame, mask = mask)[:3]
        except:
            hsv_glove = [0,0,0]
        return hsv_glove
    
    def find_gesture(self, frame):
        hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        return hsv_frame

    def find_fingers(self, frame, marker):
        #Method to find number of extended fingers
        try:
            # Creating a mask
            lower = (int(self.glove_hsv[0]-self.hsv_alpha*179),int(self.glove_hsv[1]-self.hsv_beta*255),int(self.glove_hsv[2]-self.hsv_lift_up*255))
            upper = (int(self.glove_hsv[0]+self.hsv_alpha*179),int(self.glove_hsv[1]+self.hsv_beta*255),int(self.glove_hsv[2]+self.hsv_lift_up*255))
            hsv_frame = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv_frame, np.array(lower), np.array(upper))
            res = cv2.bitwise_and(frame,frame, mask= mask)
            
            #Preprocessing the mask
            blur = cv2.GaussianBlur(mask,(5,5),0)
            ret, thresh = cv2.threshold(blur,0,255,cv2.THRESH_BINARY)
            contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            # Drawing the contours
            drawing = np.zeros(frame.shape,np.uint8)
            max_area=0
            ci=0
            cnt = 0
            for i in range(len(contours)):
                cnt=contours[i]
                area = cv2.contourArea(cnt)
                if(area>max_area):
                    max_area=area
                    ci=i
            cnt=contours[ci]
            hull = cv2.convexHull(cnt)
            moments = cv2.moments(cnt)
            if moments['m00']!=0:
                cx = int(moments['m10']/moments['m00']) # cx = M10/M00
                cy = int(moments['m01']/moments['m00']) # cy = M01/M00
            centr=(cx,cy)
            # Drawing the contours
            cv2.drawContours(drawing,[cnt],0,(0,255,0),2)
            cv2.drawContours(drawing,[hull],0,(0,0,255),2)
            hull = cv2.convexHull(cnt,returnPoints = False)
            defects = cv2.convexityDefects(cnt,hull)
            mind=0
            maxd=0
            if defects is not None:
                for i in range(defects.shape[0]):
                    s,e,f,d = defects[i,0]
                    start = tuple(cnt[s][0])
                    end = tuple(cnt[e][0])
                    far = tuple(cnt[f][0])
                    dist = cv2.pointPolygonTest(cnt,centr,True)
                    cv2.line(frame,start,end,[0,255,0],2)
                    cv2.circle(frame,far,5,[0,0,255],-1)
                if dist>self.roi_alpha1 and dist<self.roi_alpha2:
                    cv2.putText(frame,"fist",(0,50), cv2.FONT_HERSHEY_SIMPLEX, 2,(0,0,255),2,cv2.LINE_AA)
                elif dist>self.roi_alpha2 and dist<self.roi_beta:
                    cv2.putText(frame,"palm",(0,50), cv2.FONT_HERSHEY_SIMPLEX, 2,(0,0,255),2,cv2.LINE_AA)
        except:
            pass
        
        return frame
    
    def draw_ROI(self, frame, cx, cy, roi_alpha1, roi_alpha2, roi_beta, color=(255, 0, 0)):
        x1 = cx - roi_alpha1
        y1 = cy - roi_alpha2
        x2 = cx + roi_alpha1
        y2 = cy + roi_beta
        frame = cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        return frame
    
    def get_roi_corners(self):
        if self.roi_corners:
            return self.roi_corners
        return None
    
    def draw_hsv_range(self, frame, hsv_glove, color=(0,255,0)):
        lower = (int(hsv_glove[0]-self.hsv_alpha*179),int(hsv_glove[1]-self.hsv_beta*255),int(hsv_glove[2]-self.hsv_lift_up*255))
        upper = (int(hsv_glove[0]+self.hsv_alpha*179),int(hsv_glove[1]+self.hsv_beta*255),int(hsv_glove[2]+self.hsv_lift_up*255))
        frame = cv2.putText(frame, str(lower), (50,50), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2, cv2.LINE_AA)
        frame = cv2.putText(frame, str(upper), (50,100), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2, cv2.LINE_AA)
        return frame

class GestureController:
    def __init__(self, roi_alpha1=1.5, roi_alpha2=1.5, roi_beta=2.5, hsv_alpha = 0.3, hsv_beta = 0.5, hsv_lift_up = 0.3):
        self.cam_width, self.cam_height = pyautogui.size()
        self.roi = ROI(roi_alpha1, roi_alpha2, roi_beta, hsv_alpha, hsv_beta, hsv_lift_up)
        self.marker = Marker()
        self.finger_count = 0
        self.delay = 0
        self.text = ''
        
    def show_fps(self,frame):
        if self.delay == 0:
            self.start_time = time.time()
            self.delay = 1
        if self.delay == 1:
            self.end_time = time.time()
            self.delay = 2
        if self.delay == 2:
            self.delay = 0
            fps = str(int(1/(self.end_time-self.start_time)))
            cv2.putText(frame, "FPS:"+fps, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 2)
        return frame
    
    def control(self, frame):
        #Flipping the frame 
        frame = cv2.flip(frame, 1)
        # Finding Marker
        marker, roi_alpha1, roi_alpha2, roi_beta = self.marker.get_marker(frame)
        if marker is not None:
            # Drawing ROI
            frame = self.roi.draw_ROI(frame, marker[0], marker[1], roi_alpha1, roi_alpha2, roi_beta)
            # Finding HSV Range for glove
            hsv_glove = self.roi.find_glove_hsv(frame)
            frame = self.roi.draw_hsv_range(frame, hsv_glove)
            # Finding fingers
            frame = self.roi.find_fingers(frame, marker)
            # Text to be displayed
            self.text = self.roi.text
            # Text Position
            pos = (marker[0],marker[1]-50)
            # Text Color
            color = (255,0,0)
        else:
            self.text = ''
            pos = (10,50)
            color = (0,255,0)
        # Displaying text
        cv2.putText(frame,self.text,pos, cv2.FONT_HERSHEY_SIMPLEX, 2, color, 2)
        # Showing FPS
        frame = self.show_fps(frame)
        return frame

def main():
    camera = cv2.VideoCapture(0)
    camera.set(3, 1920)
    camera.set(4, 1080)
    gc = GestureController()
    while camera.isOpened():
        ret, frame = camera.read()
        if not ret:
            break
        frame = gc.control(frame)
        cv2.imshow('Frame', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    camera.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
