import pyttsx3 
import speech_recognition as sr 
import datetime
import wikipedia 
import webbrowser
from pynput.keyboard import Key, Controller
import os
from logging import shutdown
import pyautogui
import time




engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)
keyboard = Controller()



def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning sir!")

    elif hour>=12 and hour<18:
        speak("Good Afternoon sir!")   

    else:
        speak("Good Evening sir!")  

    speak("I am Devin. Please tell me how may I help you")       

def takeCommand():

    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        new_var = r.pause_threshold = 1
        audio = r.listen(source , phrase_time_limit=3)

    try:
        print("Recognizing...")    
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")

    except Exception as e:    
        speak("Say that again please...")  
        return "None"
    return query

def send_whatsapp_message(contact, message):
    webbrowser.open("https://web.whatsapp.com/")
    time.sleep(15)
    pyautogui.click(x=100, y=100)
    time.sleep(1)
    pyautogui.typewrite(contact)
    time.sleep(1)
    pyautogui.press('enter')
    time.sleep(1)
    pyautogui.click(x=200, y=200) 
    time.sleep(1)
    pyautogui.typewrite(message)
    time.sleep(1)
    pyautogui.press('enter')

if __name__ == "__main__":
    wishMe()
    while True:

        query = takeCommand().lower() 
        
        if 'send message on whatsapp' in query:
            speak("Sure, please specify the contact name.")
            contact = takeCommand().lower()
            speak("What message would you like to send?")
            message = takeCommand().lower()
            send_whatsapp_message(contact, message)
            speak("Message sent successfully!")       
    
        elif 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=1)
            speak("According to Wikipedia")
            print(results)
            speak(results)
            
        elif 'heyy devin' in query:
            speak('hello sir! What can i do for you today....!')
            
        elif 'hello' in query:
            speak('hello ,I am Devin. Please tell me how may I help you')

        elif 'open youtube' in query:
            webbrowser.open("youtube.com")  

        elif 'who are you'in query:
            speak('i am desktop assistant , developed by Dev mistry')

        elif 'how are you'in query:
            speak('i am just fine , what about you')   
             

        elif 'what are you doing now'in query:
            speak('i am just talking to you ')    
                    
        elif 'open google' in query:
            webbrowser.open("google.com")

        elif 'open stack overflow' in query:
            webbrowser.open("https://stackoverflow.com/") 

        elif "open poki games" in query:
            webbrowser.open("poki.com") 

        elif 'can you be my friend' in query:
            speak('Let’s talk for some time. Then we see if we’re good friends or not ') 

        elif 'can you shut down my pc' in query:
            speak('do you want to shut down your pc yes or not')
            shutdown =(takeCommand())
            content = takeCommand()
            if  shutdown or takeCommand() == "yes":
                speak('shuting down your pc')
                os.system('shutdown /s /t 1')
            else :
                print ('nothing !')                    

        elif 'search' in query:
            speak('Searching for ' + query.split('search')[1])
            url = 'https://google.com/search?q=' + query.split('search')[1]
            try:
                webbrowser.get().open(url)
                speak('This is what I found Sir')
            except:
                speak('Please check your Internet')
            
            
        elif 'play music' in query:
            music_dir = ('E:\\all song\\001 bhajan')
            songs = os.listdir(music_dir)
            print(songs)    
            os.startfile(os.path.join(music_dir, songs[0]))

        elif "what's time now" in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")    
            speak(f"Sir, the time is {strTime}")
            print(strTime)

        elif 'launch hand gesture recognition' in query:
            speak('Opening hand Gesture Recognition.....')
            import HandGesture
            codePath ="C:\\Users\\DELL\\OneDrive\\Desktop\\ML\\HandGesture.py"
            os.startfile(codePath) 
            
        elif 'copy' in query:
            with keyboard.pressed(Key.ctrl):
                keyboard.press('c')
                keyboard.release('c')
            speak('Copied')
            
            
        elif 'paste' in query:
            with keyboard.pressed(Key.ctrl):
                keyboard.press('v')
                keyboard.release('v')
            speak('Pasted')
            
            
        elif 'go back' in query:
            with keyboard.pressed(Key.ctrl):
                keyboard.press('z')
                keyboard.release('z')
            speak('I undo it ')
            
            
        elif ('bye' in query) or ('by' in query):
            
            hour = int(datetime.datetime.now().hour)
            if hour>=0 and hour<12:
                speak("Good Bye sir! Have Nice Day")
            elif hour>=12 and hour<18:
                speak("Good Bye sir! Have Nice Evening")  
            else:
                speak("Good Bye sir! Have a Good Night")  
        
            exit()